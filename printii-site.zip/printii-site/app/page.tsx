import PrintiiLanding from "./PrintiiLanding";
export default function Page(){ return <PrintiiLanding/> }
